package com.chorbos.fibi.Features.steps;

import androidx.appcompat.app.AppCompatActivity;

public class StepsActivity extends AppCompatActivity {
}
