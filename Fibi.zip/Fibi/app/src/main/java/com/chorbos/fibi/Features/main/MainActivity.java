package com.chorbos.fibi.Features.main;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.chorbos.fibi.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
