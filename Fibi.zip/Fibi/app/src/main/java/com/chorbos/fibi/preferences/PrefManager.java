package com.chorbos.fibi.preferences;


import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class PrefManager {

    private static final String APP_SETTINGS = "intratimePrefs";

    private static final String PREFS_SHOW_INTRO = "PREFS_SHOW_INTRO";
    private static final String PREFS_INTRO_IS_LOOPING = "PREFS_INTRO_IS_LOOPING";
    private static final String PREFS_TOKENkey = "TOKEN";
    private static final String PREFS_USERkey = "USER";
    private static final String PREFS_SYNCkey = "SYNC";

    private static SharedPreferences getSharedPreferences(@NonNull Context context) {
        return context.getSharedPreferences(APP_SETTINGS, Context.MODE_PRIVATE);
    }

    @Nullable
    public static String getUserEmail(@NonNull Context context) {
        return getSharedPreferences(context).getString(PREFS_USERkey, null);
    }

    public static void setUserEmail(@NonNull Context context, String token) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putString(PREFS_TOKENkey, token);
        editor.apply();
    }

    @Nullable
    public static String getUserToken(@NonNull Context context) {
        return getSharedPreferences(context).getString(PREFS_TOKENkey, null);
    }

    public static void setUserToken(@NonNull Context context, String token) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putString(PREFS_TOKENkey, token);
        editor.apply();
    }

    public static boolean isShowIntro(@NonNull Context context) {
        return getSharedPreferences(context).getBoolean(PREFS_SHOW_INTRO, true);
    }

    public static void setIsShowIntro(@NonNull Context context, boolean isShow) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putBoolean(PREFS_SHOW_INTRO, isShow);
        editor.apply();
    }

    public static boolean isIntroLooping(@NonNull Context context) {
        return getSharedPreferences(context).getBoolean(PREFS_INTRO_IS_LOOPING, false);
    }

    public static void setIsIntroLooping(@NonNull Context context, boolean isShow) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putBoolean(PREFS_INTRO_IS_LOOPING, isShow);
        editor.apply();
    }

    public static boolean isSyncActions(@NonNull Context context) {
        return getSharedPreferences(context).getBoolean(PREFS_SYNCkey, true);
    }

    public static void setIsSyncActions(@NonNull Context context, boolean isSync) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putBoolean(PREFS_SYNCkey, isSync);
        editor.apply();
    }

    public static void deletePreferences(Context context) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.clear();
        editor.apply();
    }


}
