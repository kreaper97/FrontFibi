package com.chorbos.fibi.Rest;


import androidx.annotation.NonNull;

import com.chorbos.fibi.Models.User;

import java.util.Date;
import java.util.List;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface ApiService {

    String DEVICE_TYPE = "android";

    int OTHERS_LANG = 1;

    int SPANISH_LANG = 2;


    ///Login User to validate it
    @NonNull
    @FormUrlEncoded
    @POST("companies/register")
    Call<User> registerUser(
            @Field("company_name") String name,
            @Field("company_mail") String email,
            @Field("company_password") String password,
            @Field("company_language") int lang
    );

    ///Login User to validate it
    @NonNull
    @FormUrlEncoded
    @POST("user/login")
    Call<User> loginUser(
            @Field("user") String user,
            @Field("pin") String password
    );

    @NonNull
    @FormUrlEncoded
    @POST("user/gauth")
    Call<?> googleAuthUser(
            @Field("code") String idToken
    );

    @NonNull
    @FormUrlEncoded
    @POST("user/clocking")
    Call<?> sendUserAction(
            @Field("inout_device_uid") String localId,
            @Field("user_action") int userAction,
            @Field("user_timestamp") String actionTime,
            @Field("user_gps_coordinates") String coordinates,
            @Field("user_project") Integer projectId,
            @Field("user_use_server_time") boolean useServerTime,
            @Field("user_comment") String comment
    );

    //get user action
    @GET("user/clockings")
    Call<List<?>> getUserActions(
            @Query("last") boolean getLast,
            @Query("maxResult") int maxResult,
            @Query("from") Date from,
            @Query("to") Date to,
            @Query("type") String types
    );
}

