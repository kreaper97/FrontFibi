package com.chorbos.fibi.Models;

import androidx.annotation.NonNull;

import com.google.gson.annotations.SerializedName;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class User extends RealmObject {

    @NonNull
    @PrimaryKey
    private String id = "1";

    @SerializedName("USER_ID")
    private String userId;

    @SerializedName("USER_NAME")
    private String name;

    @SerializedName("USER_EMAIL")
    private String email;

    @SerializedName("USER_TOKEN")
    private String token;

    @SerializedName("USER_IMAGE")
    private String userImage;

    @SerializedName("REPUTATION")
    private Double reputation;

    @SerializedName("MONEDAS")
    private int monedas;

    public Double getReputation() {
        return reputation;
    }


    public void setReputation(Double reputation) {
        this.reputation = reputation;
    }

    @NonNull
    public String getId() {
        return id;
    }

    public void setId(@NonNull String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUserImage() {
        return userImage;
    }

    public void setUserImage(String userImage) {
        this.userImage = userImage;
    }
}

