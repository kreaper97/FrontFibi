package com.chorbos.fibi.Features.Splash;


import android.content.Context;
import android.os.AsyncTask;
import android.text.TextUtils;

import androidx.annotation.IntDef;

import com.chorbos.fibi.Models.User;
import com.chorbos.fibi.preferences.PrefManager;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.ref.WeakReference;

import io.realm.Realm;

public class RealmMigrationAsyncTask extends AsyncTask<Context, Void, Integer> {


    // Define the list of accepted constants and declare the StartMode annotation
    @Retention(RetentionPolicy.SOURCE)
    @IntDef({START_INTRO, START_LOGIN, START_MAIN})
    public @interface StartMode {
    }


    public interface RealmMigrationListener {
        void onRealmMigrationDone(@StartMode Integer startMode);
    }


    static final int START_INTRO = 0;
    static final int START_LOGIN = 1;
    static final int START_MAIN = 2;

    private WeakReference<RealmMigrationListener> weakListener;

    public RealmMigrationAsyncTask(RealmMigrationListener listener) {
        this.weakListener = new WeakReference<>(listener);
    }

    @Override
    protected Integer doInBackground(Context... contexts) {
        Realm realm = null;
        try {
            realm = Realm.getDefaultInstance();
            Context context = contexts[0];
            User user = realm.where(User.class).findFirst();
            if (user != null && !TextUtils.isEmpty(user.getToken())) {
                return START_MAIN;
            } else {
                if (PrefManager.isShowIntro(context)) {
                    return START_INTRO;
                } else {
                    return START_LOGIN;
                }
            }

        } finally {
            if (realm != null) {
                realm.close();
            }
        }
    }

    @Override
    protected void onPostExecute(@StartMode Integer startMode) {
        if (weakListener.get() != null) {
            weakListener.get().onRealmMigrationDone(startMode);
        }
    }
}
