package com.chorbos.fibi.Features.Splash;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.chorbos.fibi.Features.login.LoginActivity;
import com.chorbos.fibi.Features.main.MainActivity;
import com.chorbos.fibi.Features.steps.StepsActivity;
import com.chorbos.fibi.R;

public class SplashActivity extends AppCompatActivity implements RealmMigrationAsyncTask.RealmMigrationListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        new RealmMigrationAsyncTask(this).execute(this);
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onRealmMigrationDone(@RealmMigrationAsyncTask.StartMode Integer startMode) {
        Intent intent = null;
        if (startMode == RealmMigrationAsyncTask.START_INTRO) {
            intent = new Intent(this, StepsActivity.class);
        } else if (startMode == RealmMigrationAsyncTask.START_LOGIN) {
            intent = new Intent(this, LoginActivity.class);
        } else if (startMode == RealmMigrationAsyncTask.START_MAIN) {
            intent = new Intent(this, MainActivity.class);
        }
        if (intent != null) {
            startActivity(intent);
        }
    }
}
