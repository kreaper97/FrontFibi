package com.chorbos.fibi.Service;

import android.app.job.JobParameters;
import android.app.job.JobService;

import com.chorbos.fibi.Service.async.SyncTrainingsAsyncTask;


public class SyncTrainingsJob extends JobService implements SyncTrainingsAsyncTask.SyncTrainingsListener {

    @Override
    public boolean onStartJob(JobParameters params) {
        return false;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return false;
    }

    @Override
    public void syncTrainingsNowListener(boolean isSuccess, boolean isUnauthorized) {

    }
}
