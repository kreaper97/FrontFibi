package com.chorbos.fibi.Service.async;

import android.os.AsyncTask;
import androidx.annotation.NonNull;
import java.lang.ref.WeakReference;
import io.realm.Realm;

public class SyncUserProfileAsyncTask extends AsyncTask<Void, Void, Boolean> {

    private final WeakReference<SyncUserProfileAsyncTaskListener> weakListener;
    private Realm realm;
    private boolean isSuccess = true;

    public interface SyncUserProfileAsyncTaskListener {
        void onProfileSync(boolean isSuccess);
    }

    public SyncUserProfileAsyncTask(SyncUserProfileAsyncTaskListener listener) {
        this.weakListener = new WeakReference<>(listener);
    }

    @Override
    protected Boolean doInBackground(Void... voids) {
        try {
            realm = Realm.getDefaultInstance();
            syncUserProfile();
        } catch (Exception e) {
            isSuccess = false;
        } finally {
            closeRealm();
        }
        return isSuccess;
    }

    private void syncUserProfile() {
        /*final User user = realm.where(User.class).findFirst();
        if (user != null) {
            String token = user.getToken();
            if (token != null && !token.isEmpty()) {
                ApiService apiService = ServiceGenerator.createService(ApiService.class, token);
                Call<?> call = apiService.getProfile();
                if (call != null) {
                    try {
                        Response<?> response = call.execute();
                        boolean successful = response.isSuccessful();
                        if (successful) {
                            final User userFromApi = response.body();
                            if (userFromApi != null) {
                                realm.executeTransaction(new Realm.Transaction() {
                                    @Override
                                    public void execute(@NonNull Realm realm) {
                                        Action lastAction = user.getLastAction();
                                        User userToRealmOrUpdate = realm.copyToRealmOrUpdate(userFromApi);
                                        userToRealmOrUpdate.setLastAction(lastAction);
                                    }
                                });
                            }
                        } else {
                            if(response.code() == 401){
                                deleteRealm(realm);
                            }else{
                                isSuccess = false;
                            }
                        }
                    } catch (IOException e) {
                        isSuccess = false;
                    } catch (Exception e) {
                    }
                }
            }
        }*/
    }

    private void deleteRealm(Realm realm) {
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                realm.deleteAll();
            }
        });
    }

    @Override
    protected void onPostExecute(Boolean isSuccess) {
        SyncUserProfileAsyncTaskListener syncCompanyAndAnctionListener = weakListener.get();
        if (syncCompanyAndAnctionListener != null) {
            syncCompanyAndAnctionListener.onProfileSync(isSuccess);
        }
    }

    @Override
    protected void onCancelled() {
        closeRealm();
        super.onCancelled();
    }

    private void closeRealm() {
        if (realm != null) {
            realm.close();
            realm = null;
        }
    }
}

