package com.chorbos.fibi.Application;


import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.multidex.MultiDexApplication;

import com.chorbos.fibi.Migration.MigrationApp;

import java.util.HashMap;
import io.realm.Realm;
import io.realm.RealmConfiguration;

public class FibiApp extends MultiDexApplication {


    @NonNull
    public static RealmConfiguration getRealmConfiguration() {
        return new RealmConfiguration.Builder()
                .compactOnLaunch()
                .schemaVersion(4)
                .deleteRealmIfMigrationNeeded()
                .migration(new MigrationApp())
                .build();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Realm.init(this);
        Realm.setDefaultConfiguration(getRealmConfiguration());
        //TODO - Syncronize Current Trainings
        //SyncActionsJob.scheduleJobRecurring(this);
    }
}
